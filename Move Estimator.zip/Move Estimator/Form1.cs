namespace Move_Estimator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int hours;
            int miles;
            int cost;
            hours = Convert.ToInt32(textBox1.Text);
            miles = Convert.ToInt32(textBox2.Text);
            cost = 200 + hours * 150 + miles * 2;
            label4.Text = "The Cost is $" + cost;
        }
    }
}
